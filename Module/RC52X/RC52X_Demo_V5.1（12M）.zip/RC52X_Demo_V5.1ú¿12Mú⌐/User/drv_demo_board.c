/***********************************************************************************************
*MCU�������ļ�����Ӳ�����
***********************************************************************************************/

#include "drv_demo_board.h"
#include <stdio.h>
#include "RC52X_Config.h"

static u8  fac_us=0;
static u16 fac_ms=0;


void delay_ns(u32 ns)
{
    u32 i;
    for(i=0;i<ns;i++)
    {
      __nop();
      __nop();
      __nop();
    }
}

void delay_init(u8 SYSCLK)        //unit:MHz
{
    SysTick->CTRL &= 0xfffffffb;  //select internal clk: HCLK/8
    fac_us = SYSCLK/8;      
    fac_ms = (u16)fac_us*1000;
}            

void delay_us(u32 Nus)
{ 
    SysTick->LOAD=Nus*fac_us;       //load time      
    SysTick->CTRL|=0x01;            //start count   
    while(!(SysTick->CTRL&(1<<16)));//wait time out 
    SysTick->CTRL=0X00000000;       //close counter
    SysTick->VAL=0X00000000;        //clear counter    
}

void delay_ms(u16 nms)    //nms <= 0xffffff*8/SYSCLK; for 72M, Nms<=1864 
{    
    SysTick->LOAD=(u32)nms*fac_ms; 
    SysTick->CTRL|=0x01;               
    while(!(SysTick->CTRL&(1<<16)));  
    SysTick->CTRL&=0XFFFFFFFE;         
    SysTick->VAL=0X00000000;           
}


void System_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    
    RCC_HCLKConfig(RCC_SYSCLK_Div1);
    RCC_PCLK1Config(RCC_HCLK_Div2);
    RCC_PCLK2Config(RCC_HCLK_Div1); 
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC |RCC_APB2Periph_USART1|RCC_APB2Periph_AFIO, ENABLE);
    
    RCC_MCOConfig(RCC_MCO_PLLCLK_Div2);
    ////////////////////////////////////////////////////////////////////////////////UART1
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    USART_InitStructure.USART_BaudRate = 115200;          
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStructure);
    
    USART_Cmd(USART1, ENABLE);
    USART_ClearFlag(USART1, USART_FLAG_TC); 

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   //PB10
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;                
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    FLAG_0;
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;            //LED
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    LED_1;
    delay_init(72);
    delay_ms(10);
}

void RC52X_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    SPI_InitTypeDef  SPI_InitStructure;
    EXTI_InitTypeDef  EXTI_InitStructure;
    NVIC_InitTypeDef  NVIC_InitStructure; 
    
#if (HOSTINTERFACE == INTERFACE_UART)
    USART_InitTypeDef  USART_InitStructure;    
#endif
    
    GPIO_InitStructure.GPIO_Pin = NRSTPD;                        //PA8
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;          
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;        
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    NRSTPD_0;
    
    GPIO_InitStructure.GPIO_Pin = IRQ;                           //PB11    
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;          
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource11); //IRQ

    EXTI_InitStructure.EXTI_Line = EXTI_Line11;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    
#if (IRQ_LEVEL_SET == IRQ_HIGH_LEVEL)  
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;//IRQ result interrupt
#else
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;//IRQ result interrupt
#endif

    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
    //IRQ�ж����ȼ�
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x01;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);    

    GPIO_InitStructure.GPIO_Pin = A1|A0|GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;  
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);    


#if  (HOSTINTERFACE == INTERFACE_SPI)
    ////////////////////////////////////////////////////SPI
    {
        RCC_APB1PeriphClockCmd(    RCC_APB1Periph_SPI2,  ENABLE );

        GPIO_InitStructure.GPIO_Pin = RC52X_NSS;             
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;          
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;        
        GPIO_Init(GPIOB, &GPIO_InitStructure);                 
        RC52X_NSS_1;                         
        A1_0;
        A0_1;
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15 ;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        
        SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;  
        SPI_InitStructure.SPI_Mode = SPI_Mode_Master;        
        SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;    
        SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;        
        SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;    
        SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;        
        SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_64;    //SPI_BaudRatePrescaler_256
        SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;    
        SPI_InitStructure.SPI_CRCPolynomial = 7;    
        SPI_Init(SPI2, &SPI_InitStructure);  
        SPI_Cmd(SPI2, ENABLE); 
    }
#elif (HOSTINTERFACE == INTERFACE_I2C) //IIC
    {                    
        A1_1;
        A0_1;
        GPIO_InitStructure.GPIO_Pin = SDA | SCL;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;          
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;    
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        SDA_0;
        SCL_0;
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_15;    //ADR1~0    
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6;     //ADR5~2         
        GPIO_Init(GPIOA, &GPIO_InitStructure);
        ADR5_1;        //0101,101X i2c �ӻ���ַ 
        ADR4_0;
        ADR3_1;            
        ADR2_1;
        ADR1_0;
        ADR0_1;    
    }
#else
    {
        A1_0;
        A0_0;
        RCC_APB1PeriphClockCmd( RCC_APB1Periph_USART2,ENABLE);//UART2
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;                        //TX
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(GPIOA, &GPIO_InitStructure);
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;                        //RX
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(GPIOA, &GPIO_InitStructure);
        
        USART_InitStructure.USART_BaudRate = 9600;          
        USART_InitStructure.USART_WordLength = USART_WordLength_8b;
        USART_InitStructure.USART_StopBits = USART_StopBits_1;
        USART_InitStructure.USART_Parity = USART_Parity_No;
        USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
        USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
        USART_Init(USART2, &USART_InitStructure);
        
        USART_Cmd(USART2, ENABLE);
        USART_ClearFlag(USART2, USART_FLAG_TC);     
    }
#endif

}

void modify_USART2_Baudrate(u32 baud)
{
        USART_InitTypeDef  USART_InitStructure;
        
        USART_InitStructure.USART_BaudRate = baud;          
        USART_InitStructure.USART_WordLength = USART_WordLength_8b;
        USART_InitStructure.USART_StopBits = USART_StopBits_1;
        USART_InitStructure.USART_Parity = USART_Parity_No;
        USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
        USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
        USART_Init(USART2, &USART_InitStructure);
        
        USART_Cmd(USART2, ENABLE);
        USART_ClearFlag(USART2, USART_FLAG_TC);  

}

int fputc(int ch, FILE *f)
{
    USART_SendData(USART1, (uint8_t) ch);
    while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
    return ch;
}


/***********************************************END*******************************************************/

