#ifndef __LPCD_H
#define __LPCD_H

#include "stm32f10x.h"
#include "reg.h"


void write_Lpcd_reg(u8 reg,u8 value);
u8 read_Lpcd_reg(u8 reg);
u8 Read_Q_Channel(void);
u8 Read_I_Channel(void);

void set_I_Q_threshold(u8 I_value,u8 Q_value);
void RC52X_LPCD_Start_v2(void);

u8  lanch_and_wait_irq(void);

void RC52X_Check_Card(void);
void Clear_lpcd_irq(void);
void RC52X_LPCD_Stop(void);

#endif


/***********************************************END*******************************************************/

