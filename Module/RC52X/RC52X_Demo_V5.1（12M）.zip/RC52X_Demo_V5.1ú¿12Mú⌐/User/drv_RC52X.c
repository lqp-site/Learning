/***********************************************************************************************
*RC52X�����ļ�
***********************************************************************************************/
#include <stdio.h>
#include "RC52X_Config.h"
#include "drv_demo_board.h"
#include "drv_RC52X.h"


/***********************************************************************************************
*SPI�ӿڣ����ֽڶ�дΪͬһ������
***********************************************************************************************/
u8 SPIWriteByte(u8 Byte)
{
    while((SPI2->SR&0X02)==0);         
    SPI2->DR=Byte;                     
    while((SPI2->SR&0X01)==0);     
    return SPI2->DR;                          
}

/***********************************************************************************************
*I2C�ӿ�
***********************************************************************************************/
void I2C_Start(void)
{    
    SCL_1;
    SDA_1;
    delay_ns(10);
    SDA_0;
    delay_ns(10);
    SCL_0;
    delay_ns(10);
}
void I2C_Stop(void)
{    
    SDA_0;
    SCL_1;
    delay_ns(10);
    SDA_1;
}
u8 I2C_Write(u8 dat)
{
    u8 i,re;
    for(i = 0;i < 8; i++)
    {
        if( dat & 0x80)
        {
            SDA_1;
        }
        else
        {
            SDA_0;
        }
        delay_ns(10);
        SCL_1;
        delay_ns(10);
        SCL_0;    
        dat <<= 1;
        delay_ns(10);        
    }
    SDA_1;
    delay_ns(10);
    SCL_1;
    delay_ns(10);
    if(GPIO_ReadInputDataBit(GPIOB,SDA))
    {
        re = 1;
    }
    else 
    {
       re = 0;
    }
    SCL_0;
    delay_ns(10);
    return re;
}

u8 I2C_Read(u8 ACK)
{
    u8 i;
    u8 value = 0;
    
    for(i = 0;i < 8; i++)
    {
        value <<= 1;
        SCL_1;
        delay_ns(10);
        if( GPIO_ReadInputDataBit(GPIOB,SDA) )  // sda
        {
            value ++;
        }
        SCL_0;
        delay_ns(10);
    }
    return value;
}

void I2c_NAck(void)
{
    SDA_1;
    delay_ns(10);
    SCL_1;
    delay_ns(10);
    SCL_0;    
    delay_ns(10);
}

/***********************************************************************************************
*����дһ���ֽ�
***********************************************************************************************/
void UARTWriteByte(u8 Byte)
{
    USART_SendData(USART2, Byte);
    while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
}
/***********************************************************************************************
*���ڶ�ȡһ���ֽ�
***********************************************************************************************/
u8 UARTReadByte(void)
{
    return USART_ReceiveData(USART2);
}

/***********************************************************************************************
*�޸Ĵ��ڲ�����Ϊ1228800
***********************************************************************************************/
void modify_RC52X_UART_Baudrate(void)
{
    u8 temp;
    RC52X_WriteRawRC(SerialSpeedReg,0x15);//1228800bps
    delay_ms(50);
    modify_USART2_Baudrate(1228800);
    delay_us(500);
    temp = RC52X_ReadRawRC(VersionReg);
#ifdef  UART_DEBUG
    printf("version: %X\n",temp);      
#endif
}

/***********************************************************************************************
*1907�Ĵ���ָ��λ��λ
***********************************************************************************************/
void RC52X_SetBitMask(u8   reg,u8   mask)  
{
    u8  tmp = RC52X_ReadRawRC(reg);
    RC52X_WriteRawRC(reg,tmp | mask);  
}

/***********************************************************************************************
*1907�Ĵ���ָ��λ��λ
***********************************************************************************************/
void RC52X_ClearBitMask(u8   reg,u8   mask)  
{
    u8  tmp = RC52X_ReadRawRC(reg);
    RC52X_WriteRawRC(reg, tmp & ~mask);  
}


void RC52X_WriteRawRC(u8   Address, u8   value)
{  
    u8   ucAddr;
#if (HOSTINTERFACE == INTERFACE_SPI)
    {
        RC52X_NSS_0;
        ucAddr = ((Address<<1)&0x7E);
        SPIWriteByte(ucAddr);
        SPIWriteByte(value);
        delay_us(40);
        RC52X_NSS_1;
        delay_us(40);
    }
#elif (HOSTINTERFACE == INTERFACE_I2C) //IIC
    {
        I2C_Start();
        I2C_Write(0x5A);    
        I2C_Write(Address);
        I2C_Write(value);
        I2C_Stop();
    }
#else
    {
        ucAddr= Address&0x7F;
        USART_ClearFlag(USART2, USART_FLAG_RXNE);
        UARTWriteByte(ucAddr);
        //while(USART_GetFlagStatus(UART4, USART_FLAG_RXNE) == RESET);
        //delay_ms(2);        
        UARTWriteByte(value);
        //UARTReadByte();        
        delay_ms(2);
    }
#endif
    
}

u8 RC52X_ReadRawRC(u8   Address)
{
    u8 ucAddr,ucResult=0;
    
#if (HOSTINTERFACE == INTERFACE_SPI)
    {
        RC52X_NSS_0;
        ucAddr = ((Address<<1)&0x7E)|0x80;
        SPIWriteByte(ucAddr);
        ucResult=SPIWriteByte(0);
        RC52X_NSS_1;
        delay_us(40);
    }
#elif (HOSTINTERFACE == INTERFACE_I2C) //IIC
    {
        I2C_Start();
        I2C_Write(0x5A);   
        I2C_Write(Address);
        I2C_Start();
        I2C_Write(0x5B);   
        ucResult = I2C_Read(0);
        I2c_NAck();
        I2C_Stop();
    }
#else
    {
        ucAddr = Address|0x80;
        USART_ClearFlag(USART2, USART_FLAG_RXNE);
        UARTWriteByte(ucAddr);
        //while(USART_GetFlagStatus(USART2, USART_FLAG_RXNE) == RESET);
        delay_ms(2);    
        ucResult = UARTReadByte();

    }
#endif
    return ucResult;
}

  
void RC52X_Reset(void)
{
    u8 temp;
    NRSTPD_0;
    delay_us(10);
    NRSTPD_1;
    delay_us(500); //delay 500us ��ͻ�ȷ��delay_us������ʱ׼ȷ��
    RC52X_WriteRawRC(CommandReg,RC52X_RESETPHASE);//����λ
    delay_ms(5);
    temp = RC52X_ReadRawRC(VersionReg);
#ifdef  UART_DEBUG
    printf("version: %X\n",temp);
#endif
}

void RC52X_FieldOn(void)
{
    u8 n;
    n = RC52X_ReadRawRC(TxControlReg);
    if (!(n & 0x03))
        RC52X_WriteRawRC(TxControlReg, n|0x03);
}

void RC52X_FieldOff(void)
{
    RC52X_ClearBitMask(TxControlReg, 0x03);
}



/**********************************************************************************************************
*�������ƣ�s8 RC52X_PcdComTransceive(struct TranSciveBuffer *pi)
*����������
           ����ͺ��������ֿ�ͨ�á�
*���������
           pi�����������ָ�룻
           
*���ز�����
           MI_OK���ɹ���
           other��ʧ�ܣ�
*���������
           ��
**********************************************************************************************************/
s8 RC52X_PcdComTransceive(struct TranSciveBuffer *pi)
{
    s8  status = MI_ERR;
    u8  irqEn,waitFor,n,lastBits;
    u16 i;

    switch (pi->MfCommand)
    {
        case RC52X_AUTHENT:
                irqEn   = 0x12;
                waitFor = 0x10;
                break;
        case RC52X_TRANSCEIVE:
                irqEn   = 0x77;
                waitFor = 0x30;     
                break;
        default:
                break;
    }
    
    RC52X_WriteRawRC(CommandReg,RC52X_IDLE);    //01h
    RC52X_SetBitMask(FIFOLevelReg,0x80);          //0ah,    //FlushFIFO
    RC52X_WriteRawRC(ComIrqReg,0x7F);             //04h
    
    for (i=0; i<pi->MfLength; i++)
        RC52X_WriteRawRC(FIFODataReg, pi->MfData [i]);     //09h
    
    RC52X_WriteRawRC(CommandReg, pi->MfCommand);           //01h

    if (pi->MfCommand == RC52X_TRANSCEIVE)
        RC52X_SetBitMask(BitFramingReg,0x80);              //StartSend

    //
    for(i = 500;i>0;i--)
    {
        n = RC52X_ReadRawRC(ComIrqReg);            //04h
        if((n&irqEn&0x01)||(n&waitFor))
            break;                                   //timerirq idleirq rxirq
    }
    RC52X_ClearBitMask(BitFramingReg,0x80);         //0dh        //StartSend
    
    if (n&waitFor)       //IdleIRq
    {    
        if(RC52X_ReadRawRC(ErrorReg)&0x1B)          //06h
            status = MI_ERR;
        else
        {
            status = MI_OK;
            if (pi->MfCommand == RC52X_TRANSCEIVE)
            {
                n = RC52X_ReadRawRC(FIFOLevelReg);                 //0ah
                lastBits = RC52X_ReadRawRC(ControlReg) & 0x07;     //0ch
                if (lastBits)
                    pi->MfLength = (n-1)*8 + lastBits;
                else
                    pi->MfLength = n*8;
                if (n == 0)    n = 1;
                if (n > MAXRLEN) n = MAXRLEN; 
                for (i=0; i<n; i++)
                    pi->MfData[i] = RC52X_ReadRawRC(FIFODataReg);  //09h
            }
        }
    }
    else if (n & irqEn & 0x01)    //TimerIRq
    {
        status = MI_NOTAGERR; 
    }
    else if (!(RC52X_ReadRawRC(ErrorReg)&0x1B))
    {    
        //temp = RC52X_ReadRawRC(ErrorReg);
        status = MI_ACCESSTIMEOUT;
    }

    RC52X_SetBitMask(ControlReg,0x80);             // stop timer now
    RC52X_WriteRawRC(CommandReg,RC52X_IDLE);     //01h
    return status;
}





/***********************************************END*******************************************************/

