#ifndef __drv_RC52X_H
#define __drv_RC52X_H

#include "stm32f10x.h"
#include "nfc.h"
#include "reg.h"

u8 SPIWriteByte(u8 Byte);
void RC52X_SetBitMask(u8   reg,u8   mask);
void RC52X_ClearBitMask(u8   reg,u8   mask);
void RC52X_WriteRawRC(u8   Address, u8   value);
u8 RC52X_ReadRawRC(u8   Address);
void RC52X_Reset(void);
s8 RC52X_PcdComTransceive(struct TranSciveBuffer *pi);


void modify_RC52X_UART_Baudrate(void);

void RC52X_FieldOn(void);
void RC52X_FieldOff(void);


void I2C_Start(void);
void I2C_Stop(void);
u8 I2C_Write(u8 dat);
u8 I2C_Read(u8 ACK);
void I2c_NAck(void);


#endif

/***********************************************END*******************************************************/

