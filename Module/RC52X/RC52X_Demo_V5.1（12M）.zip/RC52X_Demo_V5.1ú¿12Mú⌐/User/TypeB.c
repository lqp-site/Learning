/***********************************************************************************************
* B卡操作文件
***********************************************************************************************/
#include <stdio.h>
#include <String.h>
#include "RC52X_Config.h"
#include "drv_demo_board.h"
#include "drv_RC52X.h"
#include "TypeB.h"



void  RC52X_PcdConfigISOTypeB(void)
{
    RC52X_ClearBitMask(Status2Reg,0x08);//08h    
    RC52X_WriteRawRC(WaterLevelReg,0x10); //0bh,
    RC52X_WriteRawRC(ControlReg,0x10);//0ch, 
    RC52X_WriteRawRC(BitFramingReg,0); //0dh,
    
    RC52X_WriteRawRC(ModeReg,0x3F);//11h
    RC52X_WriteRawRC(TxModeReg,0x03); //12h, 
    RC52X_WriteRawRC(RxModeReg,0x03); //13h,   
    RC52X_WriteRawRC(TxControlReg,0x80);//14h
    RC52X_WriteRawRC(TxAutoReg,0x00); //15h,  
    RC52X_WriteRawRC(RxSelReg,0x88);//17h,        
    RC52X_WriteRawRC(RxThresholdReg,0x50); //18h,
    RC52X_WriteRawRC(DemodReg,0x4D); //19h,     
    RC52X_WriteRawRC(TypeBReg,0x00); //1eh,       
    RC52X_WriteRawRC(GsNOffReg,0xF2);   //23h    
    RC52X_WriteRawRC(ModWidthReg,0x68); //24h, 
    RC52X_WriteRawRC(RFCfgReg,0x59);   //26h 
    RC52X_WriteRawRC(GsNOnReg,0xF8);   //27h    
    RC52X_WriteRawRC(CWGsPReg,0x3f);   //28h      
    RC52X_WriteRawRC(ModGsPReg,0x2A); //29h,      
    
    RC52X_WriteRawRC(TModeReg,0x8D); //2ah,
    RC52X_WriteRawRC(TPrescalerReg,0x3e);    //2bh
    RC52X_WriteRawRC(TReloadRegL,30);//2dh
    RC52X_WriteRawRC(TReloadRegH,0); //2ch
    
    RC52X_WriteRawRC(AutoTestReg,0);        //36h    
    
    RC52X_FieldOff();
    delay_ms(5);  
    RC52X_FieldOn();
}

s8 RC52X_PcdRequestB(u8 *atqb,u8 *pLen)
{
    s8   status;  
    struct TranSciveBuffer MfComData,*pi = &MfComData; 
    RC52X_WriteRawRC(TxModeReg,0x83);          //12h
    RC52X_WriteRawRC(RxModeReg,0x83);          //13h
    RC52X_WriteRawRC(TReloadRegL,0x59);//2dh,
    RC52X_WriteRawRC(TReloadRegH,0x0A); //2ch,
    RC52X_ClearBitMask(Status2Reg,0x08); //08h
    RC52X_SetBitMask(TxControlReg,0x03);     //14h     0x03
    
    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  = 3;
    MfComData.MfData[0] = PICC_ANTI;
    MfComData.MfData[1] = 0;
    MfComData.MfData[2] = 0;
    status = RC52X_PcdComTransceive(pi);

    if (status == MI_OK)
    {
        if((MfComData.MfLength == 0x60) || (MfComData.MfLength == 0x10) )     
        {
            *pLen = MfComData.MfLength/8;
            memcpy(atqb, &MfComData.MfData[0], *pLen);
        }
        else
            status = MI_VALERR;
    }
    return status;
}

s8 RC52X_PcdAttribB(u8 *pCid)
{
    s8   status;  
    struct TranSciveBuffer MfComData,*pi = &MfComData; 

    RC52X_WriteRawRC(TPrescalerReg,0x80);    //2bh,
    RC52X_WriteRawRC(TModeReg,0x80); //2ah,
    RC52X_WriteRawRC(TReloadRegL,0xC9);//2dh,
    RC52X_WriteRawRC(TReloadRegH,0xFF); //2ch,

    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  = 9;
    MfComData.MfData[0] = PICC_ATTRIB;
    memset(&MfComData.MfData[1], 0x00, 4); //pupi
    MfComData.MfData[5] = 0;
    MfComData.MfData[6] = 0x08;
    MfComData.MfData[7] = 0x01;
    MfComData.MfData[8] = 0x08;
    status  = RC52X_PcdComTransceive(pi);

    if (status == MI_OK)
    {
        if (MfComData.MfLength != 0x8)
            status = MI_BITCOUNTERR;
        else
            *pCid = MfComData.MfData[0];
    }
   
    return status;
}

s8 RC52X_PcdGetUidB(u8 *puid)
{
    s8   status;  
    struct TranSciveBuffer MfComData,*pi = &MfComData; 
    RC52X_WriteRawRC(TxModeReg,0x83);          //12h
    RC52X_WriteRawRC(RxModeReg,0x83);          //13h

    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  =5;
    MfComData.MfData[0] =0x00; 
    MfComData.MfData[1] =0x36;
    MfComData.MfData[2] =0x00; 
    MfComData.MfData[3] =0x00;
    MfComData.MfData[4] =0x08;
    status  = RC52X_PcdComTransceive(pi);
    if ((status == MI_OK)&& (MfComData.MfLength == 0x50) )        
          memcpy(puid, &MfComData.MfData[0], 10);
    else
          status = MI_ERR; 
    return status;
}

void RC52X_SRT512(void)
{
    s8 status;
    u8 i;
    u8 RD_Data[12],Len;    
    u8 chipID;
    
    RC52X_PcdConfigISOTypeB();
    delay_ms(10);
    
    status = INITIATE_PCALL16(&chipID,&Len,0);
    if(status==MI_OK)
    {
#ifdef  UART_DEBUG
        printf("Chip_ID1: %02X",chipID);
        printf("\n");
#endif
    }
    if(status!=MI_OK) return;
    
    status = SelectChipID(RD_Data,&Len,chipID);
    if(status==MI_OK)
    {
#ifdef  UART_DEBUG
        printf("Chip_ID2: %02X",RD_Data[0]);
        printf("\n");
#endif
    }
    if(status!=MI_OK) return;
    
    status = GetUid(RD_Data);
    if(status==MI_OK)
    {
#ifdef  UART_DEBUG
        for(i=0;i<8;i++)
            printf(" %02X",RD_Data[i]);
        printf("\n");
#endif
    }
        
    if(status!=MI_OK) return;
    status = SRTReadBlock(0,RD_Data);
    if(status==MI_OK)
    {
#ifdef  UART_DEBUG
        for(i=0;i<4;i++)
            printf(" %02X",RD_Data[i]);
        printf("\n");
#endif 
    }
    
    
    if(status!=MI_OK) return;
    do
    {
        status = GetUid(RD_Data);
        if(status==MI_OK)
        {
            LED_0;
        }
        else 
        {
            LED_1;
            break;
        }
    }while(status==MI_OK);
    
}
s8 Write_ReadBlock(u8 block,u8 *Data)
{
    s8   status;
    u8 i;
    u8 random[]={0x80,0x23,0x03,0x27};
    struct TranSciveBuffer MfComData,*pi = &MfComData; 
    RC52X_WriteRawRC(TxModeReg,0x83);          //12h
    RC52X_WriteRawRC(RxModeReg,0x83);    
    MfComData.MfCommand = RC52X_TRANSMIT;
    MfComData.MfLength  =6;
    MfComData.MfData[0] =0x09; 
    MfComData.MfData[1] =block;
    for (i=0;i<4;i++)
    {
        MfComData.MfData[2+i]=random[i];
    }
    status = RC52X_PcdComTransceive(pi);
    if(status!= MI_OK) return MI_ERR;
    delay_ms(5);
    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  =2;
    MfComData.MfData[0] =0x08; 
    MfComData.MfData[1] =block;
    status  = RC52X_PcdComTransceive(pi);
    if ((status == MI_OK)&& (MfComData.MfLength == 0x20) )        
        memcpy(Data, &MfComData.MfData[0],4);
    else
        status = MI_ERR;
   
    return status;
    
}
s8 SRTReadBlock(u8 block,u8 *Data)
{
    s8   status;
    struct TranSciveBuffer MfComData,*pi = &MfComData; 
    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  =2;
    MfComData.MfData[0] =0x08; 
    MfComData.MfData[1] =block;
    status  = RC52X_PcdComTransceive(pi);
    if ((status == MI_OK)&& (MfComData.MfLength == 0x20) )        
        memcpy(Data, &MfComData.MfData[0],4);
    else
        status = MI_ERR;
   
    return status;
}
s8 GetUid(u8 *puid)
{
    s8   status;  
    struct TranSciveBuffer MfComData,*pi = &MfComData; 

    RC52X_WriteRawRC(TxModeReg,0x83);          //12h
    RC52X_WriteRawRC(RxModeReg,0x83);          //13h

    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  =1;
    MfComData.MfData[0] =0x0B; 

     status  = RC52X_PcdComTransceive(pi);
    if ((status == MI_OK)&& (MfComData.MfLength == 0x40) )        
        memcpy(puid, &MfComData.MfData[0], 8);
    else
        status = MI_ERR;
   
    return status;
}
s8 SelectChipID(u8 *atqb,u8 *pLen,u8 id)
{
    s8   status;  
    struct TranSciveBuffer MfComData,*pi = &MfComData; 

    RC52X_WriteRawRC(TxModeReg,0x83);          //12h
    RC52X_WriteRawRC(RxModeReg,0x83);          //13h
    RC52X_WriteRawRC(TReloadRegL,0x59);//2dh,
    RC52X_WriteRawRC(TReloadRegH,0x0A); //2ch,
    RC52X_ClearBitMask(Status2Reg,0x08); //08h
    RC52X_SetBitMask(TxControlReg,0x03);     //14h     
    
    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  = 2;
    MfComData.MfData[0] = 0x0E;
    MfComData.MfData[1] = id;
    
    status = RC52X_PcdComTransceive(pi);

    if (status == MI_OK)
    {
        if( MfComData.MfLength == 0x08 )     
        {
            *pLen = MfComData.MfLength/8;
            memcpy(atqb, &MfComData.MfData[0], *pLen);
        }
        else
            status = MI_VALERR;
    }
    return status;
}
s8 INITIATE_PCALL16(u8 *atqb,u8 *pLen,u8 cmd)
{
    s8   status;  
    struct TranSciveBuffer MfComData,*pi = &MfComData; 
    
    RC52X_WriteRawRC(TxModeReg,0x83);          //12h
    RC52X_WriteRawRC(RxModeReg,0x83);          //13h
    RC52X_WriteRawRC(TReloadRegL,0x59);//2dh,
    RC52X_WriteRawRC(TReloadRegH,0x0A); //2ch,
    RC52X_ClearBitMask(Status2Reg,0x08); //08h
    RC52X_SetBitMask(TxControlReg,0x03);//14h     
    
    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  = 2;
    MfComData.MfData[0] = 0x06;
    MfComData.MfData[1] = cmd;
    
    status = RC52X_PcdComTransceive(pi);

    if (status == MI_OK)
    {
        if( MfComData.MfLength == 0x08 )     
        {
            *pLen = MfComData.MfLength/8;
            memcpy(atqb, &MfComData.MfData[0], *pLen);
        }
        else
            status = MI_VALERR;
    }
    return status;
    
}

void RC52X_ChinaID2(u8 *UID_b)
{
    s8 status;
    u8 i;
    u8 RD_Data[12],Len;    
    
    memset(UID_b,0x00,8);
    RC52X_PcdConfigISOTypeB();
    delay_ms(10);
    status = RC52X_PcdRequestB(RD_Data,&Len);    

#ifdef  UART_DEBUG
    printf("ATQB: %d_",status);
    if(status==MI_OK)
    {
        for(i=0;i<Len;i++)
            printf(" %02X",RD_Data[i]);
    }
    printf("\n");
#endif

    if(status!=MI_OK) 
        return;    
    
    if(Len==12)
    {
        status = RC52X_PcdAttribB(RD_Data);

#ifdef  UART_DEBUG
        printf("SELECT:%d_",status);
        if(status==MI_OK)
            printf(" %02X",RD_Data[0]);
        printf("\n");
#endif

        if(status!=MI_OK) 
            return;
    }
    
    status = RC52X_PcdGetUidB(RD_Data);
    if(status==MI_OK)
    {
        memcpy(UID_b,RD_Data,8);
    }
    
#ifdef  UART_DEBUG
    printf("UID: %d_",status);
    for(i=0;i<8;i++) 
    {
         printf(" %02X",RD_Data[i]);
    }    
    printf("\n");
#endif
    
    //有卡则一直检测，无卡则退出
   do
    {
        RC52X_FieldOff();
        delay_ms(10);
        RC52X_FieldOn();
        LED_1;
        delay_ms(10);
        status = RC52X_PcdRequestB(RD_Data,&Len);
        if(status==MI_OK)
        {
            LED_0;
        }
        else 
            break;
    }while(status==MI_OK);
}


/**************************************************END*****************************************/

