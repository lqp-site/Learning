#ifndef __FELICA_H
#define __FELICA_H

#include "stm32f10x.h"
#include "nfc.h"
#include "reg.h"

void RC52X_Felica(u8 *UID_f);
void RC52X_PcdConfigISOTypeF(void);
s8 RC52X_PcdRequestF(u8 *pIDm,u8 *pPMm);
s8 RC52X_PcdReadF(u8 *pIDm,u8 *pDat);
void ReadmoniF(void);
#endif 

/***********************************************END*******************************************************/

