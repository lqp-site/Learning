#ifndef __drv_demo_board_H
#define __drv_demo_board_H

#include "stm32f10x.h"

#define MAXRLEN  18

#define	 FLAG_0	 	GPIO_ResetBits(GPIOB,GPIO_Pin_10)
#define	 FLAG_1	 	GPIO_SetBits(GPIOB,GPIO_Pin_10) 

#define  LED        GPIO_Pin_8
#define	 LED_0	 	GPIO_ResetBits(GPIOB,LED) 
#define	 LED_1	 	GPIO_SetBits(GPIOB,LED)

#define	 NRSTPD	 	GPIO_Pin_8				//PA8
#define	 NRSTPD_0	GPIO_ResetBits(GPIOA,NRSTPD)
#define	 NRSTPD_1	GPIO_SetBits(GPIOA,NRSTPD)

//SPI�ӿ�
#define	 RC52X_NSS	 	GPIO_Pin_12				//PB12
#define	 RC52X_NSS_0	 	GPIO_ResetBits(GPIOB,RC52X_NSS)
#define	 RC52X_NSS_1	 	GPIO_SetBits(GPIOB,RC52X_NSS)

#define	 NCS	 	GPIO_Pin_4				//PG4
#define	 NCS_0	 	GPIO_ResetBits(GPIOG,NCS)
#define	 NCS_1	 	GPIO_SetBits(GPIOG,NCS)
#define	 NWR	 	GPIO_Pin_3				//PG3
#define	 NWR_0	 	GPIO_ResetBits(GPIOG,NWR)
#define	 NWR_1	 	GPIO_SetBits(GPIOG,NWR)
#define	 NRD	 	GPIO_Pin_2				//PG2
#define	 NRD_0	 	GPIO_ResetBits(GPIOG,NRD)
#define	 NRD_1	 	GPIO_SetBits(GPIOG,NRD)
#define	 ALE	 	GPIO_Pin_8				//PG8
#define	 ALE_0	 	GPIO_ResetBits(GPIOG,ALE)
#define	 ALE_1	 	GPIO_SetBits(GPIOG,ALE)

#define	 A1	 	    GPIO_Pin_1
#define	 A1_0	 	GPIO_ResetBits(GPIOB,A1)
#define	 A1_1	 	GPIO_SetBits(GPIOB,A1)

#define	 A0	 	    GPIO_Pin_0
#define	 A0_0	 	GPIO_ResetBits(GPIOB,A0)
#define	 A0_1	 	GPIO_SetBits(GPIOB,A0)

#define	 IRQ	 	GPIO_Pin_11			//Pb11
#define  IRQ_IN     GPIO_ReadInputDataBit(GPIOB,IRQ)
#define	 I2C	 	GPIO_Pin_2				//PE2
#define	 I2C_0	 	GPIO_ResetBits(GPIOE,I2C)
#define	 I2C_1	 	GPIO_SetBits(GPIOE,I2C)
#define	 EA	 		GPIO_Pin_11				//PG11
#define	 EA_0	 	GPIO_ResetBits(GPIOG,EA)
#define	 EA_1	 	GPIO_SetBits(GPIOG,EA)


//I2C�ӿ�
#define	 SCL	 	GPIO_Pin_14
#define	 SCL_0	 	GPIO_ResetBits(GPIOB,SCL)
#define	 SCL_1	 	GPIO_SetBits(GPIOB,SCL)
#define	 SDA	 	GPIO_Pin_12
#define	 SDA_0	 	GPIO_ResetBits(GPIOB,SDA)
#define	 SDA_1	 	GPIO_SetBits(GPIOB,SDA)


#define	 ADR1_0	 	GPIO_ResetBits(GPIOB,GPIO_Pin_13)
#define	 ADR0_0	 	GPIO_ResetBits(GPIOB,GPIO_Pin_15)
#define	 ADR5_0	 	GPIO_ResetBits(GPIOA,GPIO_Pin_6)
#define	 ADR4_0	 	GPIO_ResetBits(GPIOA,GPIO_Pin_5)
#define	 ADR3_0	 	GPIO_ResetBits(GPIOA,GPIO_Pin_4)
#define	 ADR2_0	 	GPIO_ResetBits(GPIOA,GPIO_Pin_3)

#define	 ADR1_1	 	GPIO_SetBits(GPIOB,GPIO_Pin_13)
#define	 ADR0_1	 	GPIO_SetBits(GPIOB,GPIO_Pin_15)
#define	 ADR5_1	 	GPIO_SetBits(GPIOA,GPIO_Pin_6)
#define	 ADR4_1	 	GPIO_SetBits(GPIOA,GPIO_Pin_5)
#define	 ADR3_1	 	GPIO_SetBits(GPIOA,GPIO_Pin_4)
#define	 ADR2_1	 	GPIO_SetBits(GPIOA,GPIO_Pin_3)


#define	 NCS	 	GPIO_Pin_4				//PG4
#define	 NCS_0	 	GPIO_ResetBits(GPIOG,NCS)
#define	 NCS_1	 	GPIO_SetBits(GPIOG,NCS)
#define	 NWR	 	GPIO_Pin_3				//PG3
#define	 NWR_0	 	GPIO_ResetBits(GPIOG,NWR)
#define	 NWR_1	 	GPIO_SetBits(GPIOG,NWR)
#define	 NRD	 	GPIO_Pin_2				//PG2
#define	 NRD_0	 	GPIO_ResetBits(GPIOG,NRD)
#define	 NRD_1	 	GPIO_SetBits(GPIOG,NRD)
#define	 ALE	 	GPIO_Pin_8				//PG8
#define	 ALE_0	 	GPIO_ResetBits(GPIOG,ALE)
#define	 ALE_1	 	GPIO_SetBits(GPIOG,ALE)

void delay_ns(u32 ns);
void delay_init(u8 SYSCLK);
void delay_us(u32 Nus);
void delay_ms(u16 nms);

void System_Init(void);
void RC52X_Init(void);
void modify_USART2_Baudrate(u32 baud);

#endif

/***********************************************END*******************************************************/

