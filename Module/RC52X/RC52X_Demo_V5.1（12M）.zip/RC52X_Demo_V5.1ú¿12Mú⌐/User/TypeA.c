/***********************************************************************************************
* A��/Mifare�������ļ�
***********************************************************************************************/
#include <String.h>
#include <stdio.h>
#include "RC52X_Config.h"
#include "drv_demo_board.h"
#include "drv_RC52X.h"
#include "TypeA.h"

u16 ErrFlag;

s8 RC52X_JewelTransceive(struct TranSciveBuffer *pi)
{
    s8   status = MI_ERR;
    u8   waitFor,n,lastBits;
    u16  i;
    u8   temp,irqEn;
    
    irqEn   = 0x77;
    waitFor = 0x30;     
    RC52X_WriteRawRC(CommandReg,RC52X_IDLE);
    RC52X_SetBitMask(FIFOLevelReg,0x80);
    RC52X_WriteRawRC(ComIrqReg,0x7F);  
    RC52X_WriteRawRC(DivIrqReg,0x7F);
    RC52X_WriteRawRC(ManualRCVReg,0x10);
    for (i=0; i<pi->MfLength; i++)
        RC52X_WriteRawRC(FIFODataReg, pi->MfData [i]);

    RC52X_WriteRawRC(ComIEnReg,irqEn|0x80);
    RC52X_WriteRawRC(CommandReg, pi->MfCommand);
    RC52X_SetBitMask(BitFramingReg,0x80);
    do    
    {
        temp = RC52X_ReadRawRC(ComIrqReg);      //wait for TxIRQ
    } while((temp&0x40)==0); 

    if(pi->MfCommand == RC52X_TRANSMIT)
    {
        if(RC52X_ReadRawRC(ErrorReg)==0)
             status = MI_OK;
        else
             status = -1;
    }
    
    if(pi->MfCommand == RC52X_TRANSCEIVE)
    {
        RC52X_WriteRawRC(ManualRCVReg,0x00);
        
        for(i =1000;i>0;i--)
        {
            n = RC52X_ReadRawRC(ComIrqReg);      //04h
            if((n&irqEn&0x01)||(n&waitFor))break;        //timerirq idleirq rxirq
        }
    
        if (n&waitFor)       //IdleIRq
        {    
            temp = RC52X_ReadRawRC(ErrorReg);
            if(temp&0x1B)      //06h    
            {
                status = MI_ERR;
            }
            else
            {
                status = MI_OK;
                if (pi->MfCommand == RC52X_TRANSCEIVE)
                {
                    n = RC52X_ReadRawRC(FIFOLevelReg);         //0ah
                    lastBits = RC52X_ReadRawRC(ControlReg) & 0x07;     //0ch
                    if (lastBits)
                        pi->MfLength = (n-1)*8 + lastBits;
                    else
                        pi->MfLength = n*8;
                    if (n == 0)    n = 1;
                    if (n > MAXRLEN) n = MAXRLEN; 
                    for (i=0; i<n; i++)
                        pi->MfData[i] = RC52X_ReadRawRC(FIFODataReg);  //09h    
                }
            }
        }
        else if (n & irqEn & 0x01)    //TimerIRq
        {
            status = MI_NOTAGERR; 
        }
        else if (!(RC52X_ReadRawRC(ErrorReg)&0x1B))
        {    
            temp = RC52X_ReadRawRC(ErrorReg);
            status = MI_ACCESSTIMEOUT;
        }
    }
    return status;    
}

s8 RC52X_PcdConfigISOType(u8   type)
{
    if (type == 'A')             //ISO14443_A
    {
        RC52X_WriteRawRC(ControlReg,0x10);
        RC52X_WriteRawRC(TxAutoReg,0x40);
        RC52X_WriteRawRC(TxModeReg,0x00); 
        RC52X_WriteRawRC(RxModeReg,0x00);//   �����A��������
        
        RC52X_WriteRawRC(ModWidthReg,0x26); //24h  ��AB����ⶼ�У����������
        
        RC52X_WriteRawRC(BitFramingReg,0);    //0dh,
        RC52X_WriteRawRC(ModeReg,0x3D);       //11h,    
        RC52X_WriteRawRC(TxControlReg,0x84);  //14h,      
        RC52X_WriteRawRC(RxSelReg,0x88);       //17h,        
        RC52X_WriteRawRC(DemodReg,0x8D);       //19h,     //AddIQ     
        RC52X_WriteRawRC(TypeBReg,0);          //1eh,
        RC52X_WriteRawRC(TModeReg,0x8D); //2ah,
        RC52X_WriteRawRC(TPrescalerReg,0x3e);    //2bh
        RC52X_WriteRawRC(TReloadRegL,30);//2dh
        RC52X_WriteRawRC(TReloadRegH,0); //2ch
        RC52X_WriteRawRC(AutoTestReg,0);        //36h    
        
#if     (TYPEA_REG_CONFIG==REG_SET_1)
        RC52X_WriteRawRC(RxThresholdReg,0x33); //20201117
        RC52X_WriteRawRC(RFCfgReg,0x44);       //26h     
        RC52X_WriteRawRC(GsNOnReg,0xF8);       //27h        
        RC52X_WriteRawRC(CWGsPReg,0x3F);       //28h

#elif   (TYPEA_REG_CONFIG==REG_SET_2)
        RC52X_WriteRawRC(RxThresholdReg,0x33); //20201117
        RC52X_WriteRawRC(RFCfgReg,0x44);       //26h     
        RC52X_WriteRawRC(GsNOnReg,0x88);       //27h        
        RC52X_WriteRawRC(CWGsPReg,0x20);       //28h

#elif   (TYPEA_REG_CONFIG==REG_SET_3)
        RC52X_WriteRawRC(RxThresholdReg,0x42); //20201117
        RC52X_WriteRawRC(RFCfgReg,0x44);       //26h     
        RC52X_WriteRawRC(GsNOnReg,0xF8);       //27h        
        RC52X_WriteRawRC(CWGsPReg,0x3F);       //28h
 
#else   
        RC52X_WriteRawRC(RxThresholdReg,0x42); //20201117   42
        RC52X_WriteRawRC(RFCfgReg,0x59);       //26h     44
        RC52X_WriteRawRC(GsNOnReg,0x88);       //27h        
        RC52X_WriteRawRC(CWGsPReg,0x20);       //28h
#endif

        RC52X_FieldOff();
        delay_ms(5);  
        RC52X_FieldOn();//��ֹĳЩ����λ����,��ǰ����Ƶ��
        delay_ms(5);        
    }
    else if(type =='K')            //CARD SIMULATION
    {
        RC52X_WriteRawRC(TxModeReg,0x80); //12h,
        RC52X_WriteRawRC(RxModeReg,0x80); //13h,
        RC52X_WriteRawRC(RxThresholdReg,0x55); //18h,
        RC52X_WriteRawRC(DemodReg,0x61); //19h,     
        RC52X_WriteRawRC(MifareReg,0x62); //1ch, 
        RC52X_WriteRawRC(GsNOffReg,0xf2);  ///23h       
        RC52X_WriteRawRC(TxBitPhaseReg,0x87);   //25h    
        RC52X_WriteRawRC(RFCfgReg,0x59);   //26h    
        RC52X_WriteRawRC(GsNOnReg,0x6F);   //27h
        RC52X_WriteRawRC(CWGsPReg,0x3f);   //28h      
        RC52X_WriteRawRC(ModGsPReg,0x3A);   //29h          
        RC52X_WriteRawRC(TxSelReg,0x17);  //16h 
        RC52X_WriteRawRC(FIFOLevelReg,0x80);
    }
    else if(type == 'L')
    {
         
        RC52X_WriteRawRC(TxModeReg,0x92); //12h 
        RC52X_WriteRawRC(RxModeReg,0x92); //13h     
        RC52X_WriteRawRC(TxSelReg,0x17);  //16h  
        RC52X_WriteRawRC(RxThresholdReg,0x55);//18h,          
        RC52X_WriteRawRC(DemodReg,0x61);//19h         
        RC52X_WriteRawRC(RFU1A,0x00);//1Bh 
        RC52X_WriteRawRC(ManualRCVReg,0x08);
        RC52X_WriteRawRC(RFU1B,0x80);//1Bh         
        RC52X_WriteRawRC(GsNOffReg,0xf2);//23h 
        RC52X_WriteRawRC(RFCfgReg,0x59); //26h
        RC52X_WriteRawRC(GsNOnReg,0x6f); //27h
        RC52X_WriteRawRC(CWGsPReg,0x3f); //28h     
        RC52X_WriteRawRC(ModGsPReg,0x3a);//29h
        RC52X_WriteRawRC(FIFOLevelReg,0x80);
    }
   else
        return MI_ERR; 
   
   return MI_OK;
}
void RC52X_Simulate_Card(void)
{
    u8 i;
    const u8 CardConfig[]={0x04,0x00,0xa1,0xa2,0xa3,0x11,0x01,0xfe,
                            0xb2,0xb3,0xb4,0xb5,0xb6,0xb7,0xc0,0xc1,
                            0xc2,0xc3,0xc4,0xc5,0xc6,0xc7,0x23,0x45,
                            0xfa};
    RC52X_PcdConfigISOType('K');    

    for (i=0; i<25; i++)
        RC52X_WriteRawRC(FIFODataReg, CardConfig[i]);
    
    RC52X_WriteRawRC(CommandReg, RC52X_MEM);
    delay_ms(250);
    RC52X_WriteRawRC(CommandReg, RC52X_AUTOCOLL);

}
void RC52X_Simulate_CardF(void)
{
    u8 i;
    const u8 CardConfig[]={ 0x10,0xfe,0x01,0x12,0x01,0x24,0x69,0x0b,0x50,0x37,
                          0x2E,0x3d,0x24,0x69,0x0b,0x50,0x37,0x2E,
                          0x3d,0x24,0x69,0x0b,0x50,0x37,0x0b};
    RC52X_PcdConfigISOType('L');
    delay_ms(10);
    for (i=0; i<25; i++)
        RC52X_WriteRawRC(FIFODataReg, CardConfig[i]);                                                        
    
    delay_ms(100);
    RC52X_WriteRawRC(CommandReg, RC52X_MEM);
    RC52X_WriteRawRC(CommandReg, RC52X_AUTOCOLL);
}


/**********************************************************************************************************
*�������ƣ�s8 RC52X_PcdRequestA(u8   req_code,u8 *pTagType)
*����������
           Ѱ�����
*���������
           level����ײ����
           pSnr��id��
           pSize�����ȣ�
*���ز�����
           MI_OK��ѡ��ɹ���
           ������ѡ��ʧ�ܣ�
*���������
           ��
**********************************************************************************************************/
                    
s8 RC52X_PcdRequestA(u8 req_code,u8 *pTagType)
{
    s8 status;   
    struct TranSciveBuffer MfComData,*pi= &MfComData;

    RC52X_ClearBitMask(TxModeReg,0x80);//12h,    //TxCRCEn
    RC52X_ClearBitMask(RxModeReg,0x80);//13h,
    RC52X_WriteRawRC(TReloadRegL,0x59);//2dh,
    RC52X_WriteRawRC(TReloadRegH,0x0A); //2ch,
    RC52X_ClearBitMask(Status2Reg,0x08); //08h
    RC52X_WriteRawRC(BitFramingReg,0x07);     //0dh
    RC52X_SetBitMask(TxControlReg,0x03);     //14h     0x03

    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  = 1;
    MfComData.MfData[0] = req_code;
    FLAG_1;
    status = RC52X_PcdComTransceive(pi);
    FLAG_0;
    if (status == MI_OK) 
    { 
        if(MfComData.MfLength == 0x10)
        {
            *pTagType     = MfComData.MfData[0];
            *(pTagType+1) = MfComData.MfData[1];
        }
        else
            status = MI_VALERR;
    }
    return status;
}

/**********************************************************************************************************
*�������ƣ�s8 RC52X_PcdSelect(u8 level,u8 *pSnr,u8 *pSize)
*����������
           ѡ��������
*���������
           level����ײ����
           pSnr��id��
           pSize�����ȣ�
*���ز�����
           MI_OK��ѡ��ɹ���
           ������ѡ��ʧ�ܣ�
*���������
           ��
**********************************************************************************************************/

s8 RC52X_PcdSelect(u8 level,u8 *pSnr,u8 *pSize)
{
    s8   status;
    u8   i,snr_check = 0;
    struct TranSciveBuffer MfComData,*pi = &MfComData;
    
    RC52X_WriteRawRC(TxModeReg,0x80);          //12h        TxCRCEn
    RC52X_WriteRawRC(RxModeReg,0x80);          //13h
    
    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  = 7;
    MfComData.MfData[0] = level;
    MfComData.MfData[1] = 0x70;
    for (i=0; i<4; i++)
    {
        snr_check ^= *(pSnr+i);
        MfComData.MfData[i+2] = *(pSnr+i);
    }
    MfComData.MfData[6] = snr_check;
    status = RC52X_PcdComTransceive(pi);
    
    if (status == MI_OK)
    {
    if (MfComData.MfLength != 0x8)
        status = MI_BITCOUNTERR;
    else
        *pSize = MfComData.MfData[0];
    }

    return status;
}

/**********************************************************************************************************
*�������ƣ�s8 RC52X_PcdAuthState(u8 auth_mode,u8 block,u8 *pKey,u8 *pSnr)
*����������
           ��Կ��֤������
*���������
           auth_mode����֤ģʽ��
           block��Ҫ��֤�������ţ�
           pKey����Կָ�
           pSnr��
*���ز�����
           MI_OK��д�ɹ���
           ��������֤����
*���������
           ��
**********************************************************************************************************/

s8 RC52X_PcdAuthState(u8 auth_mode,u8 block,u8 *pKey,u8 *pSnr)
{
    s8 status;
    u8 reg;
    struct TranSciveBuffer MfComData,*pi = &MfComData;
    
    MfComData.MfCommand = RC52X_AUTHENT;
    MfComData.MfLength  = 12;
    MfComData.MfData[0] = auth_mode;
    MfComData.MfData[1] = block;
    memcpy(&MfComData.MfData[2], pKey, 6); 
    memcpy(&MfComData.MfData[8], pSnr, 4); 
    status = RC52X_PcdComTransceive(pi);
    if (status == MI_OK) 
    {  
        reg = RC52X_ReadRawRC(Status2Reg);
        if(!(reg&0x08))
             status = MI_AUTHERR;
    }
    return status;
}
/**********************************************************************************************************
*�������ƣ�s8 RC52X_PcdRead(u8   addr,u8 *pReaddata)
*����������
           ��ָ��������
*���������
           addr�������ţ�
           pWritedata������ָ�룻
*���ز�����
           MI_OK��д�ɹ���
           ��������֤����
*���������
           ��
**********************************************************************************************************/

s8 RC52X_PcdRead(u8   addr,u8 *pReaddata)
{
    s8 status;
    struct TranSciveBuffer MfComData,*pi = &MfComData;

    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  = 2;
    MfComData.MfData[0] = PICC_READ;
    MfComData.MfData[1] = addr;
    status = RC52X_PcdComTransceive(pi);
    if (status == MI_OK)
    {
        if (MfComData.MfLength != 0x80)
            status = MI_BITCOUNTERR;
        else
            memcpy(pReaddata, &MfComData.MfData[0], 16);
    }
    return status;
}

/**********************************************************************************************************
*�������ƣ�s8 RC52X_PcdWrite(u8   addr,u8 *pWritedata)
*����������
           дָ��������
*���������
           addr�������ţ�
           pWritedata������ָ�룻
*���ز�����
           MI_OK��д�ɹ���
           MI_NOTAUTHERR����֤����
*���������
           ��
**********************************************************************************************************/

s8 RC52X_PcdWrite(u8   addr,u8 *pWritedata)
{
    s8 status;
    struct TranSciveBuffer MfComData,*pi = &MfComData;
    
    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  = 2;
    MfComData.MfData[0] = PICC_WRITE;
    MfComData.MfData[1] = addr;
    status = RC52X_PcdComTransceive(pi);
    if (status != MI_NOTAGERR)
    {
        if(MfComData.MfLength != 4)
            status=MI_BITCOUNTERR;
        else
        {
            MfComData.MfData[0] &= 0x0F;
            switch (MfComData.MfData[0])
            {
                case 0x00:
                    status = MI_NOTAUTHERR;
                    break;
                case 0x0A:
                    status = MI_OK;
                    break;
                default:
                    status = MI_CODEERR;
                    break;
            }
        }
    }    
    if (status == MI_OK)
    {
        MfComData.MfCommand = RC52X_TRANSCEIVE;
        MfComData.MfLength  = 16;
        memcpy(&MfComData.MfData[0], pWritedata, 16);
        status = RC52X_PcdComTransceive(pi);
        if (status != MI_NOTAGERR)
        {
            MfComData.MfData[0] &= 0x0F;
            switch(MfComData.MfData[0])
            {
                case 0x00:
                    status = MI_WRITEERR;
                    break;
                case 0x0A:
                    status = MI_OK;
                    break;
                default:
                    status = MI_CODEERR;
                    break;
            }
        }
    }
    return status;
}

/**********************************************************************************************************
*�������ƣ�s8 RC52X_PcdHaltA(void)
*����������
           ������ͣ���������
*���������
           addr�������ţ�
           pWritedata������ָ�룻
*���ز�����
           MI_OK�������ɹ���
           ����������ʧ�ܣ�
*���������
           ��
**********************************************************************************************************/

s8 RC52X_PcdHaltA(void)
{
    s8 status;
    struct TranSciveBuffer MfComData,*pi = &MfComData;
    
    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  = 2;
    MfComData.MfData[0] = PICC_HALT;
    MfComData.MfData[1] = 0;
    status = RC52X_PcdComTransceive(pi);
    if (status)
    {
        if (status==MI_NOTAGERR || status==MI_ACCESSTIMEOUT)
             status = MI_OK;
    }
    RC52X_WriteRawRC(CommandReg,RC52X_IDLE);
    return status;
}

/**********************************************************************************************************
*�������ƣ�s8 RC52X_PcdAnticoll(u8 level,u8 *pSnr)
*����������
           ��ײ������
*���������
           level����ײ����
           pSnr��UIDָ�룻
*���ز�����
           MI_OK�������ɹ���
           ����������ʧ�ܣ�
*���������
           ��
**********************************************************************************************************/

s8 RC52X_PcdAnticoll(u8 level,u8 *pSnr)
{
    s8 status ;
    u8 i;
    u8 ucBits,ucBytes;
    u8 snr_check = 0;
    u8 ucCollPosition = 0;
    u8 ucTemp;
    u8 ucSNR[5] = {0, 0, 0, 0 ,0};
    struct TranSciveBuffer MfComData,*pi = &MfComData;

    RC52X_WriteRawRC(BitFramingReg,0x00);        
    RC52X_ClearBitMask(CollReg,0x80);             
    RC52X_ClearBitMask(TxModeReg,0x80);
    RC52X_ClearBitMask(RxModeReg,0x80);    
    do
    {
        ucBits = (ucCollPosition) % 8;
        if (ucBits != 0)
        {
             ucBytes = ucCollPosition / 8 + 1;
             RC52X_WriteRawRC(BitFramingReg, (ucBits << 4) + ucBits);
        }
        else
             ucBytes = ucCollPosition / 8;
        
        
        MfComData.MfCommand = RC52X_TRANSCEIVE;
        MfComData.MfData[0] = level;
        MfComData.MfData[1] = 0x20 + ((ucCollPosition / 8) << 4) + (ucBits & 0x0F);
        for (i=0; i<ucBytes; i++)
            MfComData.MfData[i + 2] = ucSNR[i];
        MfComData.MfLength = ucBytes + 2;
        
        FLAG_1;
        status = RC52X_PcdComTransceive(pi);
        FLAG_0;
        
        ucTemp = ucSNR[(ucCollPosition / 8)];
        if (status == MI_COLLERR)
        {
            for (i=0; i < 5 - (ucCollPosition / 8); i++)
                ucSNR[i + (ucCollPosition / 8)] = MfComData.MfData[i+1];
            ucSNR[(ucCollPosition / 8)] |= ucTemp;
            ucCollPosition = MfComData.MfData[0];
        }
        else if (status == MI_OK)
        {
            for (i=0; i < (MfComData.MfLength / 8); i++)
                ucSNR[4 - i] = MfComData.MfData[MfComData.MfLength/8 - i - 1];
            ucSNR[(ucCollPosition / 8)] |= ucTemp;
        }
    } while (status == MI_COLLERR);
        
    if (status == MI_OK)
    {
        for (i=0; i<4; i++)
        {   
            *(pSnr+i)  = ucSNR[i];
            snr_check ^= ucSNR[i];
        }
        if (snr_check != ucSNR[i])
            status = MI_COM_ERR;
    }
    
    RC52X_SetBitMask(CollReg,0x80);
    return status;
}

void printStatus(const char *message,s8 status,u8 *pbuf,u8 len)
{
#ifdef  UART_DEBUG
    u8 i;
    printf("%s: %d_",message,status);
    if(status==MI_OK || status==MI_FRAMINGERR)
    {
        for(i=0;i<len;i++)
            printf(" %02X",*(pbuf+i));
    }
    printf("\n");
#endif
}

void UpdateCrc_B(u8 bCh, u16 *pLpwCrc)
{
    bCh = (bCh^(u8)((*pLpwCrc)&0x00FFU));
    bCh = (bCh ^ (bCh<<4U));
    *pLpwCrc = (*pLpwCrc >> 8U) ^ ((uint16_t)bCh << 8U) ^ ((u16)bCh << 3U) ^ ((u16)bCh>>4U);
}

void ComputeCrc_B( u8 *pData,u32 dwLength,u8 *pCrc)
{
    u8 bChBlock = 0;
    u16 wCrc = 0xFFFF;
    do
    {
            bChBlock = *pData++;
            UpdateCrc_B(bChBlock, &wCrc);
    } while (0u != (--dwLength));
    wCrc = ~wCrc;
    pCrc[0] = (u8) (wCrc & 0xFFU);
    pCrc[1] = (u8) ( (wCrc>>8U) & 0xFFU);
}

s8 RC52X_PcdJewelCommand(u8* pdata,u8 len,u8* resp,u8* replen)
{
    s8 status;
    struct TranSciveBuffer ComData,*pi = &ComData;
    u8 i;
    u8 crc[2];
    for(i=0;i<len-1;i++)
    {
        if(i==0)
        {
            RC52X_WriteRawRC(BitFramingReg,0x07);
        }
        else 
        {
            RC52X_WriteRawRC(BitFramingReg,0x00);
        }
        ComData.MfCommand = RC52X_TRANSMIT;
        ComData.MfLength  = 1;
        ComData.MfData[0] = *(pdata+i);    
        FLAG_0;
        status = RC52X_JewelTransceive(pi);
        FLAG_1;

        if(status != MI_OK)
        return status;
    }
    ComData.MfCommand = RC52X_TRANSCEIVE;
    ComData.MfLength  = 1;
    ComData.MfData[0] = *(pdata+len-1);    
    status = RC52X_JewelTransceive(pi);
    FLAG_0;
    if(status == MI_OK)
    {
        *replen = ComData.MfLength/8;
        if (*replen != 0)
        {
            memcpy(resp, &ComData.MfData[0], *replen);
            ComputeCrc_B(resp,*replen-2,crc);
            if(crc[0]!=resp[*replen-2] || crc[1]!=resp[*replen-1])
                status = MI_CRCERR;
        }
    }
    return status;
}


s8 RC52X_PcdRidA(u8 *pUid)        
{
    s8   status;
    u8 cmd_rid[9]={0x78,0,0,0,0,0,0};
    u8 resp[8];
    u8 len;
  
    ComputeCrc_B(cmd_rid,7,&cmd_rid[7]);
    status = RC52X_PcdJewelCommand(cmd_rid,sizeof(cmd_rid),resp,&len);
    printStatus("RID",status,resp,len);
    if(status==MI_OK)
    {
        memcpy(pUid, &resp[2], 4);
    }
    return status;
} 


s8 RC52X_PcdReadA(u8 *pUid)        
{
    s8   status;
    u8 cmdbuf[9]={1,8,0};
    u8 resp[8];
    u8 len;
    memcpy(&cmdbuf[3],pUid,4);
    ComputeCrc_B(cmdbuf,7,&cmdbuf[7]);
    status = RC52X_PcdJewelCommand(cmdbuf,sizeof(cmdbuf),resp,&len);
    printStatus("Read",status,resp,len);
    return status;
} 


s8 RC52X_PcdJewel(void)
{
    s8   status;
    u8 uid[4];
    status = RC52X_PcdRidA(uid);
    if(status!=MI_OK) 
        return status;
    status = RC52X_PcdReadA(uid);
    return status;
}


/**********************************************************************************************************
*�������ƣ�s8 RC52X_PcdActivateA(u8 *patqa,u8 *puid,u8 *plen,u8 *psak)
*����������
           ��ȡA�������з�ײ������
*���������
           patqa��puid��plen��psak����Ҫ�������ݵ�ָ�룻

*���ز�����
           patqa����
           puid��ID��
           plen��ID���ȣ�
           psak�����ͣ�
*���������
           ��
**********************************************************************************************************/

s8 RC52X_PcdActivateA(u8 *patqa,u8 *puid,u8 *plen,u8 *psak)
{
    s8 status;

    RC52X_PcdConfigISOType('A');
    delay_ms(10);
    status = RC52X_PcdRequestA(PICC_REQIDL,patqa);

#ifdef  UART_DEBUG
    printf("ATQA: %d_",status);
    if(status==MI_OK)
        printf(" %02X %02X",patqa[1],patqa[0]);
    printf("\n");
#endif

    if(status!=MI_OK) 
        return status;
    
    if(*(patqa+1)==0x0C && *patqa==0 )    
    {
        *plen = 6;
        status = RC52X_PcdJewel();
        if(status!=MI_OK) return status;
    }
    else    
    {
        *plen = 4;
        status = RC52X_PcdAnticoll(PICC_ANTICOLL1,puid);
        printStatus("UID1",status,puid,4);
        if(status!=MI_OK) return status;

        status = RC52X_PcdSelect(PICC_ANTICOLL1,puid,psak);
        printStatus("SEL1",status,psak,1);
        if(status!=MI_OK) return status;
        
        if(*patqa&0xC0)    //level 2
        {
            *plen = 8;
            status = RC52X_PcdAnticoll(PICC_ANTICOLL2,puid+4);
            printStatus("UID2",status,puid+4,4);
            if(status!=MI_OK) return status;

            status = RC52X_PcdSelect(PICC_ANTICOLL2,puid+4,psak);
            printStatus("SEL2",status,psak,1);
            if(status!=MI_OK) return status;
        }
        
        if(*patqa&0x80)    //level 3
        {
            *plen = 12;
            status = RC52X_PcdAnticoll(PICC_ANTICOLL3,puid+8);
            printStatus("UID3",status,puid+8,4);
            if(status!=MI_OK) return status;

            status = RC52X_PcdSelect(PICC_ANTICOLL3,puid+8,psak);
            printStatus("SEL3",status,psak,1);
            if(status!=MI_OK) return status;
        }
    }
    return status;
}

void RC52X_SetBaudrate(u8 txrate,u8 rrate)
{
    u8 tempt,tempr;
    
    tempt = RC52X_ReadRawRC(TxModeReg);
    tempr = RC52X_ReadRawRC(RxModeReg);
    
    switch(txrate)
    {
        case 0:    //106k        
            RC52X_WriteRawRC(TxModeReg,tempt&0x8f); //2fh,
          
            RC52X_WriteRawRC(ModWidthReg,0x26);      
            break;
        case 1:    //212k
            RC52X_WriteRawRC(TxModeReg,tempt&0x9f); //2fh,
            RC52X_WriteRawRC(TxModeReg,tempt|0x10);
        
            RC52X_WriteRawRC(ModWidthReg,0x10);
            break;
        case 2:    //424k
            RC52X_WriteRawRC(TxModeReg,tempt&0xaf); //2fh,
            RC52X_WriteRawRC(TxModeReg,tempt|0x20);

            RC52X_WriteRawRC(ModWidthReg,0x07);        
            break;
        case 3:    //848k
            RC52X_WriteRawRC(TxModeReg,tempt&0xbf); //2fh,
            RC52X_WriteRawRC(TxModeReg,tempt|0x30);
        
            RC52X_WriteRawRC(ModWidthReg,0x02);          
            break;
        default://106k
            RC52X_WriteRawRC(TxModeReg,tempt&0x8f);  //2fh,
            RC52X_WriteRawRC(ModWidthReg,0x26);
            break;
    }
    switch(rrate)
    {
        case 0:    //106k
            RC52X_WriteRawRC(RxModeReg,tempr&0x8f); //35h,
            break;
        case 1:    //212k
            RC52X_WriteRawRC(RxModeReg,tempr&0x9f); //2fh,
            RC52X_WriteRawRC(RxModeReg,tempr|0x10);
            break;
        case 2:    //424k
            RC52X_WriteRawRC(RxModeReg,tempr&0xaf); //2fh,
            RC52X_WriteRawRC(RxModeReg,tempr|0x20);
            break;
        case 3:    //848k
            RC52X_WriteRawRC(RxModeReg,tempr&0xbf); //2fh,
            RC52X_WriteRawRC(RxModeReg,tempr|0x30);
            break;
        default://106k
            RC52X_WriteRawRC(RxModeReg,tempr&0x8f); //35h,
            break;
    }
}


u8 RC52X_RatsA(u8 *pbuf,u8 *plen)
{
    s8   status;
    struct TranSciveBuffer ComData,*pi = &ComData;

    ComData.MfCommand = RC52X_TRANSCEIVE;
    ComData.MfLength  = 2;
    ComData.MfData[0] = 0xE0;    
    ComData.MfData[1] = 0x51;    //default=0x51    Fsdi,CID

    status = RC52X_PcdComTransceive(pi);
    if (status == MI_OK)
    {
        *plen = ComData.MfLength/8;
    memcpy(pbuf, &ComData.MfData[0], *plen);    
    }
    return status;
}

u8 RC52X_PpsA(u8 param,u8 *pPpss)
{
    s8   status;
    struct TranSciveBuffer ComData,*pi = &ComData;

    ComData.MfCommand = RC52X_TRANSCEIVE;
    ComData.MfLength  = 3;
    ComData.MfData[0] = 0xD1;    //0xD0 | CID    
    ComData.MfData[1] = 0x11;    //default=0x51    bFsdi,bCid
    ComData.MfData[2] = param;    //0x0A(424,424);    0x0F(848,848)

    status = RC52X_PcdComTransceive(pi);
    if (status == MI_OK)
    {
    if (ComData.MfLength != 8)
        status = MI_BITCOUNTERR;
    else
        *pPpss = ComData.MfData[0];    //
    }
    return status;
}

s8 RC52X_PcdMfulRead(u8   addr,u8 *pReaddata)
{
    s8 status;
    struct TranSciveBuffer ComData,*pi = &ComData;

    RC52X_SetBitMask(TxModeReg,0x80);//12h,    //TxCRCEn
    RC52X_SetBitMask(RxModeReg,0x80);//13h,
    
    ComData.MfCommand = RC52X_TRANSCEIVE;
    ComData.MfLength  = 2;
    ComData.MfData[0] = PICC_READ;
    ComData.MfData[1] = addr;
    status = RC52X_PcdComTransceive(pi);
    if(status == MI_OK)
    {
        if (ComData.MfLength != 0x80)
            status = MI_BITCOUNTERR;
        else
            memcpy(pReaddata, &ComData.MfData[0], 16);
    }

    return status;
}

u8 RC52X_CPU_I_Block(u8 *psbuf,u8 slen,u8 *prbuf,u8 *prlen)
{
    s8   status;
    struct TranSciveBuffer ComData,*pi = &ComData;

    RC52X_WriteRawRC(TReloadRegL,0x0B);//2dh,        //30    
    RC52X_WriteRawRC(TReloadRegH,0x41);    
    ComData.MfCommand = RC52X_TRANSCEIVE;
    ComData.MfLength  = slen+2;
    ComData.MfData[0] = 0x0A;    //PCB    
    ComData.MfData[1] = 0x01;    //Cid
    memcpy(&ComData.MfData[2], psbuf, slen);
    status = RC52X_PcdComTransceive(pi);
    if (status == MI_OK)
    {
        *prlen= ComData.MfLength/8;
        memcpy(prbuf, &ComData.MfData[0], *prlen);
    }
    return status;
}

/**********************************************************************************************************
*�������ƣ�void RC52X_TypeA(u8 *UID_a, u8 *len)
*����������
           ��ȡA������UID��
*���������
           UID_a��len����Ҫ�������ݵ�ָ�룻

*���ز�����
           UID_a��ID��
           len��ID���ȣ�

*���������
           ��
**********************************************************************************************************/

void RC52X_TypeA(u8 *UID_a, u8 *len)
{
    s8 status;
    u8 atqa[7];
    u8 uid[12],ulen;
    u8 sak,i;
    u8 RD_Data[16];        
    static u8 KEY[6]={0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
    u8 ver1 = 0x60;
    u8 random[]={0x00,0x84,0x00,0x00,0x08};
    
    *len=0;
    memset(UID_a,0x00,7);
    NRSTPD_0;
    delay_us(10);
    NRSTPD_1;
    delay_us(500);
    status = RC52X_PcdActivateA(atqa,uid,&ulen,&sak);
    if(status==MI_OK)
    {
        if(ulen==8)
        {
            *len=ulen-1;
            memcpy(UID_a,&uid[1],7);
        }
        else
        {
            *len=ulen;
            memcpy(UID_a,uid,4);
        }
    }
    else
    {
        return;
    }
    if(ulen!=6)        
    {
        if(sak&0x04)
        {
#ifdef  UART_DEBUG
            printf("uid not complete");
#endif
            return;
        }
        if(sak&0x20)    //compliant with ISO-14443-4    
        {
            status = RC52X_RatsA(RD_Data,&ulen);
            printStatus("Rats",status,RD_Data,ulen);
            if(status!=MI_OK) return;
            
            if((RD_Data[1]&0x10)&&(RD_Data[2]&0x44)==0x44)    //TA(1) 848k supported    //mifare desfire
            {        
                status = RC52X_PpsA(0x0f,&sak);  //106:0x00   212:0x05  424:0x0a  848:0x0f
                printStatus("Pps",status,&sak,1);
                if(status!=MI_OK) return;                
                    RC52X_SetBaudrate(3,3);        //106��0��0  212��1��1   424��2��2   848��3��3    
                status = RC52X_CPU_I_Block(&ver1,1,uid,&ulen);
                printStatus("ver1",status,uid,ulen);
                if(status!=MI_OK) return;
                    RC52X_WriteRawRC(ModWidthReg,0x26);                
                RC52X_SetBaudrate(0,0);                
            }
            else
            {
                status = RC52X_CPU_I_Block(random,5,uid,&ulen);
                printStatus("random",status,uid,ulen);
                if(status!=MI_OK) return;
            }
        }
        else if(ulen==4)    //not compliant with ISO-14443-4    
        {
            if(sak==0x08 && atqa[0]==0x04)
            {
#ifdef  UART_DEBUG
                printf("mifare S50 has detected!\n");
#endif
            }
            else if(sak==0x18 && atqa[0]==0x02)
            {
#ifdef  UART_DEBUG
                printf("mifare S70 has detected!\n");
#endif 
            }
            status = RC52X_PcdAuthState(0x60,0x00,KEY,&uid[0]);

#ifdef  UART_DEBUG
            printf("AUTH: %X\n",status);
#endif

            status=RC52X_PcdRead(0,RD_Data);
            
#ifdef  UART_DEBUG
            printf("READ:%d_",status);
            for(i=0;i<16;i++)
                printf(" %02X",RD_Data[i]);
            printf("\n");
#endif
            if(status!=MI_OK) 
                return;
        }
        else
        {
            status = RC52X_PcdMfulRead(3,RD_Data);
            printStatus("MfulRead",status,RD_Data,16);
            if(status!=MI_OK) return;    
        }
    }
    
    //�п���һֱ��⣬�޿����˳�        
    do
    {
        RC52X_FieldOff();
        delay_ms(10);
        RC52X_FieldOn();
        LED_1;
        delay_ms(10);
        status = RC52X_PcdRequestA(PICC_REQALL,atqa);
        if(status==MI_OK)
        {
            LED_0;
        }
        else 
            break;
    }while(status==MI_OK);
}


/**************************************************END*****************************************/


