#ifndef __TYPEA_H
#define __TYPEA_H

#include "stm32f10x.h"
#include "nfc.h"
#include "reg.h"


u8 RC52X_SelfTest(void);
void RC52X_CalulateCRC(u8 *pIn ,u8 len,u8 *pOut );

s8 RC52X_PcdConfigISOType(u8 type);
s8 RC52X_PcdActivateA(u8 *patqa,u8 *puid,u8 *plen,u8 *psak);
s8 RC52X_PcdRequestA(u8 req_code,u8 *pTagType);
s8 RC52X_PcdAnticoll(u8 level,u8 *pSnr);
s8 RC52X_PcdSelect(u8 level,u8 *pSnr,u8 *pSize);
s8 RC52X_PcdAuthState(u8 auth_mode,u8 addr,u8 *pKey,u8 *pSnr);
s8 RC52X_PcdWrite(u8 addr,u8 *pData);
s8 RC52X_PcdRead(u8 addr,u8 *pData);
s8 RC52X_PcdHalt(void);
u8 RC52X_RatsA(u8 *pbuf,u8 *plen);
u8 RC52X_PpsA(u8 param,u8 *pPpss);
s8 RC52X_PcdMfulRead(u8   addr,u8 *pReaddata);
u8 RC52X_CPU_I_Block(u8 *psbuf,u8 slen,u8 *prbuf,u8 *prlen);
s8 RC52X_PcdJewelCommand(u8* pdata,u8 len,u8* resp,u8* replen);
s8 RC52X_PcdRidA(u8 *pUid);
s8 RC52X_PcdReadA(u8 *pUid);
s8 RC52X_PcdJewel(void);

s8 RC52X_PcdPollingF(u8 *p);


void RC52X_TypeA(u8 *UID_a, u8 *len);
void RC52X_SetBaudrate(u8 txrate,u8 rrate);
void RC52X_Simulate_Card(void);
s8 RC52X_JewelTransceive(struct TranSciveBuffer *pi);
void RC52X_Simulate_CardF(void);
void test_input_voltage(void);
void test_TSTIIN_TSTQIN(void);
void test_TST_DF(void);


#endif

/**************************************************END*****************************************/

