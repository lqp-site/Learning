/***********************************************************************************************
*FeliCa操作函数文件
***********************************************************************************************/
#include <stdio.h>
#include <String.h>
#include "drv_demo_board.h"
#include "drv_RC52X.h"
#include "RC52X_Config.h"
#include "Felica.h"




/***********************************************************************************************
*配置为FeliCa卡
***********************************************************************************************/
void RC52X_PcdConfigISOTypeF(void)
{
		RC52X_ClearBitMask(Status2Reg,0x08);//08h        //MFCrypto1On
		RC52X_WriteRawRC(WaterLevelReg,0x10); //0bh,
		RC52X_WriteRawRC(ControlReg,0x10);//0ch, //Initiator
		RC52X_WriteRawRC(BitFramingReg,0); //0dh,
		RC52X_WriteRawRC(ModeReg,0x00);//11h,    *00*
		RC52X_WriteRawRC(TxModeReg,0x92); //12h, 212k
		RC52X_WriteRawRC(RxModeReg,0x92); //13h,  212k
		RC52X_WriteRawRC(TxControlReg,0x80);//14h,    
		RC52X_WriteRawRC(TxAutoReg,0x00); //15h,
		RC52X_WriteRawRC(TxSelReg,0x10);//16h
		RC52X_WriteRawRC(RxSelReg,0x83);//17h
		RC52X_WriteRawRC(RxThresholdReg,0x55); //18h        55  
		RC52X_WriteRawRC(RFCfgReg,0x59);   //26h   59      
		RC52X_WriteRawRC(GsNOnReg,0xFF);   //27h  FF
		RC52X_WriteRawRC(CWGsPReg,0x3F);   //28h    3F 
		RC52X_WriteRawRC(ModGsPReg,0x12); //29h   12
		RC52X_FieldOff();
		delay_ms(5);  
		RC52X_FieldOn(); 

}

s8 RC52X_PcdRequestF(u8 *pIDm,u8 *pPMm)
{
    s8   status;  
    struct TranSciveBuffer MfComData,*pi = &MfComData; 

    RC52X_WriteRawRC(TPrescalerReg,0x01);    //2bh,
    RC52X_WriteRawRC(TModeReg,0x80); //2ah,
    RC52X_WriteRawRC(TReloadRegL,0xEC);//2dh,
    RC52X_WriteRawRC(TReloadRegH,0x5C); //2ch,
    
    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  =6;
    MfComData.MfData[0] =0x06; 
    MfComData.MfData[1] =0;
    MfComData.MfData[2] =0xFF; 
    MfComData.MfData[3] =0xFF;
    MfComData.MfData[4] =0;
    MfComData.MfData[5] =0;
    FLAG_0;
    status  = RC52X_PcdComTransceive(pi);
    FLAG_1;
    if (status == MI_OK)
    {
        if(MfComData.MfLength == 0x90)
        {
            memcpy(pIDm, &MfComData.MfData[2], 8);
            memcpy(pPMm, &MfComData.MfData[10], 8);
        }
        else
            status = MI_VALERR;
    }
    return status;
}

s8 RC52X_PcdReadF(u8 *pIDm,u8 *pDat)
{
    s8 status; 
    struct TranSciveBuffer MfComData,*pi= &MfComData;
    
    MfComData.MfCommand = RC52X_TRANSCEIVE;
    MfComData.MfLength  = 16;
    MfComData.MfData[0] = 0x10;        //len
    MfComData.MfData[1] = 0x06;
    memcpy(&MfComData.MfData[2],pIDm, 8);
    MfComData.MfData[10] = 1;            //bNumServices
    MfComData.MfData[11] = 0x0B;    //pServiceList..
    MfComData.MfData[12] = 0;
    MfComData.MfData[13] = 1;            //read how much number of block
    MfComData.MfData[14] = 0x80;    //pBlockList..
    MfComData.MfData[15] = 0x01;
    status = RC52X_PcdComTransceive(pi);
    if (status == MI_OK)
    {
        if(MfComData.MfLength == 0xE8)        
        {
            memcpy(pDat, &MfComData.MfData[13], 16);
        }
        else
            status = MI_VALERR;
    }
    return status;
}

/***********************************************************************************************
*检测并读取FeliCa卡函数
***********************************************************************************************/
void RC52X_Felica(u8 *UID_f)
{
    s8 status;
    u8 i;
    u8 IDm[8],PMm[8],buf[16];   
	
    memset(UID_f,0x00,8);
		NRSTPD_0;
		delay_us(500);
		NRSTPD_1;
		delay_us(500);
    RC52X_PcdConfigISOTypeF();    
    delay_ms(10);        
    status = RC52X_PcdRequestF(IDm,PMm);

#ifdef  UART_DEBUG
    printf("ATQF: %d_",status);
    if(status==MI_OK)
    {
        for(i=0;i<8;i++)
            printf(" %02X ",IDm[i]);
        printf("_");
        for(i=0;i<8;i++)
            printf(" %02X",PMm[i]);
        memcpy(UID_f,&IDm[0],8);
    }
    printf("\n");
#endif

    if(status!=MI_OK) return;
    
    status = RC52X_PcdReadF(IDm,buf);

#ifdef  UART_DEBUG
    printf("Read: %d_",status);
    if(status==MI_OK)
    {
        for(i=0;i<16;i++)
            printf(" %02X",buf[i]);
    }
    printf("\n");
#endif

    if(status!=MI_OK) return;
    //有卡则一直检测，无卡则退出
    do
    {
        RC52X_FieldOff();
        delay_ms(10);
        RC52X_FieldOn();
        LED_1;
        delay_ms(10);
        status = RC52X_PcdRequestF(IDm,PMm);
        if(status==MI_OK)
            LED_0;
        else 
            break;
    }while(status==MI_OK);
}
/***********************************************END*******************************************************/

