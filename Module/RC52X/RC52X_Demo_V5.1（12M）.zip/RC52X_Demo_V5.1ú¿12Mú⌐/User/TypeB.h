#ifndef __TYPEB_H
#define __TYPEB_H

#include "stm32f10x.h"
#include "nfc.h"
#include "reg.h"



void RC52X_ChinaID2(u8 *UID_b);
void  RC52X_PcdConfigISOTypeB(void);
s8 RC52X_PcdRequestB(u8 *atqb,u8 *pLen);
s8 RC52X_PcdAttribB(u8 *pCid);
s8 RC52X_PcdGetUidB(u8 *puid);

void RC52X_SRT512(void);
s8 INITIATE_PCALL16(u8 *atqb,u8 *pLen,u8 cmd);
s8 SelectChipID(u8 *atqb,u8 *pLen,u8 id);
s8 GetUid(u8 *puid);
s8 Write_ReadBlock(u8 block,u8 *Data);
s8 SRTReadBlock(u8 block,u8 *Data);

#endif 
