#ifndef __RC52X_Config_H
#define __RC52X_Config_H


//set IRQ LEVEL
#define IRQ_HIGH_LEVEL  1     //set high level irq
#define IRQ_LOW_LEVEL   2     //set low level irq

#define IRQ_LEVEL_SET   IRQ_HIGH_LEVEL   //设为高电平中断



//set irq output mode
#define IRQ_OUT_PP      1     //set IRQ CMOS ouput
#define IRQ_OUT_OD      2     //set IRQ OPEN drain

#define IRQ_OUT_MODE    IRQ_OUT_PP  //中断输出设置为CMOS

//sensitive adjust, 0-8
#define SENSITIVE_MIN         0
#define SENSITIVE_SEC         2
#define SENSITIVE_MID         4
#define SENSITIVE_SIX         6
#define SENSITIVE_MAX         8

#define LPCD_Sensitive_Value  SENSITIVE_MID //灵敏度设置


/* set check cycle */
#define CHECK_PERIOD_110MS    0x08ff   //110ms +-12%
#define CHECK_PERIOD_220MS    0x10ff   //220ms +-12%
#define CHECK_PERIOD_330MS    0x1aff   //330ms +-12%
#define CHECK_PERIOD_430MS    0x22ff   //430ms +-12%

/*设置LPCD检测周期*/
#define LPCD_Cycle_Time       CHECK_PERIOD_430MS   //430ms


/* set LPCD check time */
#define CHECK_TIME_10US       0x007f   //10us
#define CHECK_TIME_05US       0x003f   //5us
#define CHECK_TIME_2D5US      0x001f   //2.5us

/*选择检卡时长*/
#define LPCD_Duration_Time    CHECK_TIME_10US   //2.5us


/* 读卡寄存器配置，不同的天线适配不同的配置，选择最优的定义 */
#define REG_SET_1          1    //A卡寄存配置1
#define REG_SET_2          2    //A卡寄存配置2
#define REG_SET_3          3    //A卡寄存配置3
#define REG_SET_4          4    //A卡寄存配置4

#define TYPEA_REG_CONFIG   REG_SET_4     //选择寄存器配置4


/* 通讯接口定义 */
#define INTERFACE_SPI      1
#define INTERFACE_I2C      2
#define INTERFACE_UART     3    

/* 通讯接口选择 */
#define HOSTINTERFACE      INTERFACE_SPI  //SPI接口


/*调试信息是否通过口口打印定义，有定义则打印，无定义则不打印*/
#define UART_DEBUG



#endif

/***********************************************END*******************************************************/

