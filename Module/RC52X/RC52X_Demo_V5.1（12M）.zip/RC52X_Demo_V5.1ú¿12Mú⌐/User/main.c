
#include "stm32f10x.h"
#include <stdio.h>
#include <math.h>
#include "RC52X_Config.h"
#include "drv_demo_board.h"
#include "drv_RC52X.h"
#include "TypeA.h"
#include "TypeB.h"
#include "Felica.h"
#include "LPCD.h"


u8 UID_a[12],len;
u8 UID_b[12];
u8 UID_f[12];  
int main(void)
{
	System_Init();
	RC52X_Init();
	RC52X_Reset();
#ifdef  UART_DEBUG
	printf("reset!!!!\n");
#endif
	LED_0;
	delay_ms(100);
	LED_1;
	delay_ms(100);
	while(1)
	{	
		
		/*读取A卡并返回ID和长度*/
		RC52X_TypeA(UID_a,&len);
		
		/*读取B卡并返回8字节ID*/    
		RC52X_ChinaID2(UID_b);

	 /*读取F卡并返回8字节IDm*/ 
		RC52X_Felica(UID_f);
		    
		delay_ms(200);
        
	}
}


/***********************************************END*******************************************************/



